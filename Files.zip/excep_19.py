# simple code
try:
    print("code start")
    print(1 / 0)        # in this operation error occurs

except:
    print("an error occurs")

# finally block always execute
finally:
    print("GeeksForGeeks")