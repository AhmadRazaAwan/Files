# Create a Files in Python.
# To create a new file "a" is used.

# File name is text and type is .txt using single quotation.
file1 = open('text.txt', 'a')

# File name is info and type is .txt using double quotation.
file2 = open("info.txt", "a")