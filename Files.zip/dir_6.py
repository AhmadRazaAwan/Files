# In order to remove a non-empty directory, we can use the rmtree() method inside the shutil module.

import os

# give error because information is not empty they have files
# print(os.rmdir("information"))

