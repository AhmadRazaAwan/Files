# open a Files in Python


# open file in current directory
f = open("text.txt")

# open file in other directory
# Give them  a full path
f = open("C:/Users/Raza Awan/PycharmProjects/Files/text.txt")
