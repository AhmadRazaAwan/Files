# We can also make a new directory

import os

# it's make a new directory(folder) name Allah
os.mkdir("Allah")

print(os.listdir())
