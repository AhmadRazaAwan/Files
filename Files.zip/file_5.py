# Write a Files in Python
# To create a file "w" is used.
# w for write

f = open('text.txt', "w")