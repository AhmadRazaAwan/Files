# There are a large number of files in Python program,
# To handle different scenario

import os

# This command give the path of current file
print(os.getcwd())

print(os.getcwdb())

# We can change directory
# Giving new path where we want to go.

# os.chdir("C:\Users\Raza Awan\PycharmProjects\Files")

# now it return a new path

# print(os.getcwd())