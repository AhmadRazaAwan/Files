# Removing a directory or a file
import os

# Print list of directory
print(os.listdir())

# rename name (old name), (new name)
os.rename("Allah", "My Allah")

# Again print list to check
print(os.listdir())
