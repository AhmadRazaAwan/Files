import os

# Return a current path
print(os.getcwd())

# Showing the all file and folders name of this path
print(os.listdir())