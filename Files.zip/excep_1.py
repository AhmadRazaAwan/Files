# Two types of Error
# Syntax errors
# Logical errors (Exceptions)


# it's syntax Error (We missed : )
#if a < 3


# Logical Error
#print(1/0)