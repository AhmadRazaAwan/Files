# when working with files in text mode, it is highly recommended to specify the encoding type.

# For Windows encoding="cp1252"
# and
# For Linus encoding="utf-8"
f = open("text.txt", mode="r", encoding="cp1252")
