#The try block does not raise any errors, so the else block is executed:

try:
    print("Hello Everyone")
except:
    print("Somting Wrong")
else:
    print("Code run Perfectly")