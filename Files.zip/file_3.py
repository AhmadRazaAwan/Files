# Read a Files in Python.
# To read a file "r" is used.
# r for read


f = open('text.txt', "r")