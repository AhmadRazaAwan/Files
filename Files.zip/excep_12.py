# initialize the amount variable
amount = 10000

# check that You are eligible to
#  purchase Dsa Self Paced or not
# if (amount > 2999)
# syntax Error