# initialize the amount variable
marks = 10000

# perform division with 0
# Divide by zero Error
a = marks / 0
print(a)