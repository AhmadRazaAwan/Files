# In this code x is not pre defined
# So when they try to print x they see their is no x
# So they go in except part.

try:
    print(x)
except:
    print("An exception occurred")