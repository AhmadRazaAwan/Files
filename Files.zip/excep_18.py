# Program to for Raising Exception

try:
    raise NameError("Hi there")  # Raise Error
except NameError:
    print("An exception")