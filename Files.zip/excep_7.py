# As a Python developer you can choose exception if a condition occurs.

a = -1

if a < 0:
    raise Exception("sorry no number below zero")